// Autores: Félix Aguilar, Adrián Bennasar, Álvaro Bueno
#include "directorios.h"

// Variable global para el último fichero escrito.
struct UltimaEntrada UltimaEntradaEscritura;
struct UltimaEntrada UltimaEntradaLectura;

/* Función: extraer_camino:
* -------------------------
* Esta función descompone el camino indicado por parámetro en dos, inicial y 
* final, los cuales son el siguiente paso y los próximos pasos en el camino 
* respectivamente.
* 
*  camino: dirección del fichero del dispositivo virtual.
*  inicial: directorio o fichero más próximo al directorio actual.
*  final: camino restante después de inicial.
*  tipo: indica si inicial es un fichero o un directorio.
*
* returns: Exit_Success o bien Exit_Failure si se produce un error
*/
int extraer_camino(const char *camino, char *inicial, char *final, char *tipo)
{
    // Si el camino no comienza con '/' entonces error.
    if (*(camino) != '/')
    {
        return EXIT_FAILURE;
    }

    // Localiza la primera barra después de la inicial.
    char *f = strchr((camino + 1), '/');
    *(tipo) = 'f';

    // Dependiendo de si existe el carácter '/' se realiza lo siguiente.
    if (f)
    {
        // Si existe, recoge el elemento inicial y el resto lo guarda en final.
        strncpy(inicial, (camino + 1), (strlen(camino) - strlen(f) - 1));
        strcpy(final, f);

        // Si el primer carácter de final es '/', inicial es un directorio.
        if (final[0] == '/')
        {
            *(tipo) = 'd';
        }
    }
    else
    {
        // Si no existe, copia camino en inicial y final lo indica como vacío.
        strcpy(inicial, (camino + 1));
        final[0] = '\0';
    }

    return EXIT_SUCCESS;
}

/* Función: buscar_entrada:
* -------------------------
* Esta función buscará una determinada entrada en el sistema de archivos, la 
* cual dependiendo del valor de reservar, reservará o no un inodo para el 
* elemento. Además de esto devuelve el identificador de su inodo.
*
*  camino_parcial: camino a recorrer para llegar al destino.
*  p_inodo_dir: identificador del inodo del directorio padre.
*  p_inodo: identificador del inodo del destino a obtener.
*  p_entrada: número de entrada dentro del directorio padre.
*  reservar: indicador si se ha de crear un nuevo elemento o no (1 o 0).
*  permisos: permisos a tener por el nuevo elemento (si reservar = 1).
*
* return: devuelve un código de error para ser procesado por la función 
*         mostrar_error_directorios si es menor que 0. Si ha sido correcta la
*         ejecución devolverá Exit_Success.
*/
int buscar_entrada(const char *camino_parcial, unsigned int *p_inodo_dir,
                   unsigned int *p_inodo, unsigned int *p_entrada,
                   char reservar, unsigned char permisos)
{
    // Si el camino percial es la raíz.
    if (!strcmp(camino_parcial, "/"))
    {
        // Lee el superbloque.
        struct superbloque SB;
        if (bread(SBPOS, &SB) == -1)
        {
            return ERROR_ACCESO_DISCO;
        }
        // Guarda el pinodo del directorio raíz y finaliza la ejecución.
        *(p_inodo) = SB.posInodoRaiz;
        *(p_entrada) = 0;
        return EXIT_SUCCESS;
    }

    // Lee el inodo del directorio padre.
    struct inodo inodo;
    if (leer_inodo(*(p_inodo_dir), &inodo))
    {
        return ERROR_ACCESO_DISCO;
    }

    // Comprueba que este tenga permiso de lectura.
    if ((inodo.permisos & 4) != 4)
    {
        return ERROR_PERMISO_LECTURA;
    }

    // Instancia las variables a utilizar.
    struct entrada entrada;
    char inicial[sizeof(entrada.nombre)];
    char final[strlen(camino_parcial)];
    char tipo;

    // Inicializa los buffers como arrays vacíos.
    memset(inicial, 0, sizeof(entrada.nombre));
    memset(final, 0, strlen(camino_parcial));
    memset(entrada.nombre, 0, sizeof(entrada.nombre));

    // Obtiene el elemento inicial y su tipo además del final del camino.
    if (extraer_camino(camino_parcial, inicial, final, &tipo))
    {
        return ERROR_CAMINO_INCORRECTO;
    }
#if DEBUG
    printf("[buscar_entrada()->inicial: %s, final: %s, reservar: %d]\n", inicial,
           final, reservar);
#endif
    // Obtiene el número total de entradas en el inodo e inicializa el índice.
    int cantEntradasInodo = inodo.tamEnBytesLog / sizeof(struct entrada);
    int numEntradaInodo = 0;

    // Si hay entradas en el inodo.
    if (cantEntradasInodo > 0)
    {
        // Inicializa un array de entradas que caben en un bloque.
        struct entrada entradas[BLOCKSIZE / sizeof(struct entrada)];

        /* Se itera mientras haya entradas sin procesar o bien no se haya 
           encontrado el elemento incial. */
        while ((numEntradaInodo < cantEntradasInodo) && strcmp(entrada.nombre,
                                                               inicial))
        {
            // Obtiene la dirección física del bloque de entradas a procesar.
            int bloquef = traducir_bloque_inodo(
                *(p_inodo_dir),
                numEntradaInodo / ((BLOCKSIZE / sizeof(struct entrada)) - 1), 0);
            if (bloquef != -1)
            {
                // Lee el contenido del bloque de entradas.
                memset(entradas, 0, BLOCKSIZE);
                int bytes;
                if ((bytes = bread(bloquef, entradas)) == -1)
                {
                    return ERROR_ACCESO_DISCO;
                }
                /* Itera por el contenido del bloque de entradas mientras no se 
               hayan procesado todas las entradas de este o bien encontrado el 
               elemento inicial.*/
                int numEntradaArray = 0;
                while (numEntradaArray < ((bytes / sizeof(struct entrada)) - 1) &&
                       strcmp(entradas[numEntradaArray].nombre, inicial) &&
                       (numEntradaInodo < cantEntradasInodo))
                {
                    // Avanza dentro de las entradas del inodo.
                    numEntradaArray++;
                    numEntradaInodo++;
                }
                /* Si no se ha sobrepasado el número de elementos del directorio y 
               el elemento se ha encontrado, copia sus datos en entrada. */
                if (cantEntradasInodo != numEntradaInodo &&
                    !strcmp(entradas[numEntradaArray].nombre, inicial))
                {
                    strcpy(entrada.nombre, entradas[numEntradaArray].nombre);
                    entrada.ninodo = entradas[numEntradaArray].ninodo;
                }
            }
            else
            {
                numEntradaInodo = cantEntradasInodo;
            }
        }
    }
    // Si inicial no se ha encontrado y se han procesado todas las entradas.
    if (cantEntradasInodo == numEntradaInodo && strcmp(entrada.nombre, inicial))
    {
        /* Dependiendo del estado introducido en reservar, se realiza diferentes
           acciones. */
        switch (reservar)
        {
        case 0:
            return ERROR_NO_EXISTE_ENTRADA_CONSULTA;
            break;
        case 1:
            /* Comprueba que el inodo sea diferente de fichero y tenga permisos
               de escritura. */
            if (inodo.tipo == 'f')
            {
                return ERROR_NO_ES_UN_DIRECTORIO;
            }
            if ((inodo.permisos & 2) != 2)
            {
                return ERROR_PERMISO_ESCRITURA;
            }
            else
            {
                /* Copia inicial en entrada y revisa que el tipo de inicial sea
                   directorio. */
                strcpy(entrada.nombre, inicial);
                if (tipo == 'd')
                {
                    // Revisa que el final sea '/'.
                    if (!strcmp(final, "/"))
                    {
                        // Reserva un inodo para el nuevo directorio.
                        entrada.ninodo = reservar_inodo(tipo, permisos);
#if DEBUG
                        printf("[buscar()->reservado inodo %d tipo %c con perm"
                               "isos %d para %s]\n",
                               entrada.ninodo, tipo, permisos, entrada.nombre);
#endif
                        if (entrada.ninodo == -1)
                        {
                            return ERROR_ACCESO_DISCO;
                        }
                    }
                    else
                    {
                        return ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO;
                    }
                }
                else
                {
                    // Reserva un inodo para el nuevo fichero.
                    entrada.ninodo = reservar_inodo(tipo, permisos);
#if DEBUG
                    printf("[buscar()-> reservado inodo %d tipo %c con permisos"
                           " %d para %s]\n",
                           entrada.ninodo, tipo, permisos, entrada.nombre);
#endif
                    if (entrada.ninodo == -1)
                    {
                        return ERROR_ACCESO_DISCO;
                    }
                }
                // Guarda la nueva entrada en el directorio pertinente.
                if (mi_write_f(*(p_inodo_dir), &entrada, inodo.tamEnBytesLog,
                               sizeof(struct entrada)) == -1)
                {
                    liberar_inodo(entrada.ninodo);
                    return EXIT_FAILURE;
                }
#if DEBUG
                printf("[buscar_entrada()-> creada entrada: %s, %d]\n",
                       entrada.nombre, entrada.ninodo);
#endif
            }
            break;
        }
    }
    // Si se ha llegado al final del procesado entonces.
    if (!strcmp(final, "") || !strcmp(final, "/"))
    {
        // Si se ha encontrado el elemento y está en modo escritura entonces.
        if ((numEntradaInodo < cantEntradasInodo) && (reservar == 1))
        {
            return ERROR_ENTRADA_YA_EXISTENTE;
        }
        // Si no devuelve la entrada pertinente.
        *(p_inodo) = entrada.ninodo;
        *(p_entrada) = numEntradaInodo;
        return EXIT_SUCCESS;
    }
    else
    {
        /* Si no se ha llegado al final se pasa a procesar el siguiente 
           elemento del camino, llamada recursiva. */
        *(p_inodo_dir) = entrada.ninodo;
        return buscar_entrada(final, p_inodo_dir, p_inodo, p_entrada, reservar,
                              permisos);
    }
}

/* Función: mi_creat:
* -------------------
* Utilizada para crear un fichero o un directorio y su entrada en el directorio
* padre.
*
*  camino: dirección completa con el camino donde se creará el elemento.
*  permisos: permisos que tendrá el elemento.
*
* returns: Exit_Success o código de error si se ha producido un error.
*/
int mi_creat(const char *camino, unsigned char permisos)
{
    // Inicialización de variables.
    unsigned int p_inodo_dir = 0;
    unsigned int p_inodo = 0;
    unsigned int p_entrada = 0;
    int error;

    // Espera para entrar en la sección crítica.
    mi_waitSem();

    // Crea el nuevo elemento.
    if ((error = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 1,
                                permisos)) < 0)
    {
        mi_signalSem();
        return error;
    }
    mi_signalSem();
    return EXIT_SUCCESS;
}

/* Función: mi_dir:
* -----------------
* Esta función devuelve el contenido del directorio o bien la información de un 
* archivo en el buffer. La información de cada elemento del directorio es tipo, 
* permisos, fecha de modificación, tamaño y nombre y estan divididos por el 
* carácter '|'. Esta función requiere la función auxiliar formato_ls.
* 
*  camino: dirección del elemento.
*  buffer: buffer donde almacenará el contenido del directorio para imprimir.
*
* returns: el total de entradas procesadas o bien el código de error para ser 
*          procesado por la función mostrar_error_directorios.
*/
int mi_dir(const char *camino, char *buffer)
{
    // Comprueba que el camino está bien escrito.
    if (camino[0] != '/')
    {
        return ERROR_CAMINO_INCORRECTO;
    }
    // Inicializa las variables necesarias.
    unsigned int p_inodo_dir = 0;
    unsigned int p_inodo = 0;
    unsigned int p_entrada = 0;
    int error;

    // Realiza la búsqueda del elemento en el sistema de archivos.
    if ((error = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 0,
                                0)) < 0)
    {
        return error;
    }
    // Obtiene el inodo del sistema de archivos.
    struct inodo inodo;
    if (leer_inodo(p_inodo, &inodo))
    {
        return ERROR_ACCESO_DISCO;
    }
    // Comprueba si el inodo pertenece a un directorio.
    if (inodo.tipo != 'd')
    {
        // Obtiene la entrada del archivo en el directorio padre.
        struct entrada entrada;
        if (mi_read_f(p_inodo_dir, &entrada, p_entrada * sizeof(struct entrada),
                      sizeof(struct entrada)) < 0)
        {
            return ERROR_ACCESO_DISCO;
        }
        // Obtiene la información de la entrada y la guarda en el buffer.
        if ((error = formato_ls(entrada, buffer)) < 0)
        {
            return error;
        }
        return 1;
    }
    // Comprueba que el directorio tenga permisos de lectura.
    if ((inodo.permisos & 4) != 4)
    {
        return ERROR_PERMISO_LECTURA;
    }
    /* Variables utilizadas para obtener los bytes a leer y el total de 
       entradas procesadas. */
    int offset = 0;
    int totalEntradas = 0;

    // Inicializa y limpia el buffer de entradas.
    struct entrada entradas[BLOCKSIZE / sizeof(struct entrada)];
    memset(&entradas, 0, sizeof(struct entrada));

    // Lee el primer bloque de entradas del directorio.
    int bytes = mi_read_f(p_inodo, &entradas, offset, BLOCKSIZE);

    // Itera mientras haya entradas que leer.
    while (bytes > 0)
    {
        // Número de entradas que se han leído del disco.
        int entradasBloque = bytes / sizeof(struct entrada);
        totalEntradas = totalEntradas + entradasBloque;

        // Itera por todas las entradas leídas del disco.
        int idx = 0;
        while (idx < entradasBloque)
        {
            // Obtiene la información de la entrada en el formato adecuado.
            if ((error = formato_ls(entradas[idx], buffer)) < 0)
            {
                return error;
            }
            idx++;
        }
        // Leer siguiente bloque de entradas del disco.
        offset = bytes + offset;
        memset(&entradas, 0, sizeof(struct entrada));
        bytes = mi_read_f(p_inodo, &entradas, offset, BLOCKSIZE);
    }
    return totalEntradas;
}

/* Función: formato_ls:
* -----------------
* Esta función devuelve el contenido de un elemento dentro de un buffer con el
* formato adecuado para ejecutar un ls.
* 
*  entrada: dirección del elemento.
*  buffer: buffer donde almacenará el contenido del directorio para imprimir.
*
* returns: Exit_Success si ha ido correctamente o código de error a procesar
* por la función mostrar_error_directorios. 
*          .
*/
int formato_ls(struct entrada entrada, char *buffer)
{
    // Obtiene la información del inodo de la entrada.
    struct STAT stat;
    if (mi_stat_f(entrada.ninodo, &stat))
    {
        return ERROR_ACCESO_DISCO;
    }
    // Escribir entrada en el buffer con el formato adecuado.
    char array[11];
    sprintf(array, "%c\t", stat.tipo);
    strcat(buffer, array);
    if (stat.permisos & 4)
    {
        strcat(buffer, "r");
    }
    else
    {
        strcat(buffer, "-");
    }
    if (stat.permisos & 2)
    {
        strcat(buffer, "w");
    }
    else
    {
        strcat(buffer, "-");
    }
    if (stat.permisos & 1)
    {
        strcat(buffer, "x\t\t");
    }
    else
    {
        strcat(buffer, "-\t\t");
    }
    struct tm *tm;
    char tmp[100];
    tm = localtime(&stat.mtime);
    sprintf(tmp, "%d-%02d-%02d %02d:%02d:%02d\t", tm->tm_year + 1900,
            tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min,
            tm->tm_sec);
    strcat(buffer, tmp);
    sprintf(array, "%d\t", stat.tamEnBytesLog);
    strcat(buffer, array);
    strcat(buffer, entrada.nombre);
    strcat(buffer, "|");
    return EXIT_SUCCESS;
}

/* Función: mi_chmod:
* -------------------
* Esta función permite cambiar los permisos de un elemento.
*
*  camino: dirección del elemento del cual se quiere cambiar los permisos.
*  permisos: nuevos permisos que tendrá el elemento.
*
* return: devuelve Exit_Success si ha ido correctamente o bien un código de 
*         error para la función mostrar_error_directorios.
*/
int mi_chmod(const char *camino, unsigned char permisos)
{
    // Inicialización de las variables a utilizar.
    unsigned int p_inodo_dir = 0;
    unsigned int p_inodo = 0;
    unsigned int p_entrada = 0;
    int error;

    // Obtiene el pinodo del elemento en el sistema de archivos.
    if ((error = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 0,
                                permisos)) < 0)
    {
        return error;
    }

    // Modifica los permisos del elemento.
    if (mi_chmod_f(p_inodo, permisos))
    {
        return ERROR_ACCESO_DISCO;
    }
    return EXIT_SUCCESS;
}

/* Función: mi_stat:
* ------------------
* Esta función obtiene la metainformación del elemento indicado por el camino.
*
*  camino: dirección del elemento a obtener la información.
*  p_stat: metainformación del elemento.
*
* returns: el número del inodo o bien un código de error si se ha prducido un 
*          error al buscar el elemento.
*/
int mi_stat(const char *camino, struct STAT *p_stat)
{
    // Inicialización de las variables.
    unsigned int p_inodo_dir = 0;
    unsigned int p_inodo = 0;
    unsigned int p_entrada = 0;
    int error;

    // Obtención del inodo del elemento en el sistema de archivos.
    if ((error = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 0,
                                0)) < 0)
    {
        return error;
    }
    // Obtención de la metainformación.
    if (mi_stat_f(p_inodo, p_stat))
    {
        return ERROR_ACCESO_DISCO;
    }
    return p_inodo;
}

/* Función: mi_write:
* ------------------
* Esta función permite la escritura del contenido de un buffer en un archivo.
*
*  camino: dirección del archivo donde se va a escribir.
*  buf: buffer con el contenido a escribir.
*  offset: desplazamiento de bytes dentro del archivo.
*  nbytes: tamaño en bytes de buffer.
*
* returns: número de bytes escritos o bien el error generado.         
*/
int mi_write(const char *camino, const void *buf, unsigned int offset,
             unsigned int nbytes)
{
    // Inicialización de las variables.
    unsigned int p_inodo_dir = 0;
    unsigned int p_inodo = 0;
    unsigned int p_entrada = 0;
    int error;
    int bytes = 0;

    // Revisa si este ha sido el último archivo accedido.
    if (strcmp(camino, UltimaEntradaEscritura.camino))
    {
        // Obtención del inodo del elemento en el sistema de archivos.
        if ((error = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada,
                                    0, 0)) < 0)
        {
            return error;
        }
        // Actualiza la variable global del último fichero leído.
        strcpy(UltimaEntradaEscritura.camino, camino);
        UltimaEntradaEscritura.p_inodo = p_inodo;
#if DEBUG
        printf("\n[mi_write() -> Actualizamos la caché de escritura]\n");
#endif
    }
    else
    {
        // Utiliza el p_inodo de memoria.
        p_inodo = UltimaEntradaEscritura.p_inodo;
#if DEBUG
        printf("\n[mi_write() -> Utilizamos la caché de escritura en vez de llam"
               "ar a buscar_entrada()]\n");
#endif
    }
    // Realiza la escritura del buffer.
    bytes = mi_write_f(p_inodo, buf, offset, nbytes);
    if (bytes == -1)
    {
        return ERROR_PERMISO_ESCRITURA;
    }
    return bytes;
}

/* Función: mi_read:
* ------------------
* Esta función permite la lectura del contenido de un archivo en un buffer.
*
*  camino: dirección del archivo donde se va a escribir.
*  buf: buffer con el contenido a escribir.
*  offset: desplazamiento de bytes dentro del archivo.
*  nbytes: tamaño en bytes de buffer.
*
* returns: número de bytes leídos o bien el error generado.         
*/
int mi_read(const char *camino, void *buf, unsigned int offset,
            unsigned int nbytes)
{
    // Inicialización de las variables.
    unsigned int p_inodo_dir = 0;
    unsigned int p_inodo = 0;
    unsigned int p_entrada = 0;
    int error;
    int bytes = 0;

    // Revisa si este ha sido el último archivo accedido.
    if (strcmp(camino, UltimaEntradaLectura.camino))
    {
        // Obtención del inodo del elemento en el sistema de archivos.
        if ((error = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada,
                                    0, 0)) < 0)
        {
            return error;
        }
        // Actualiza la variable global del último fichero leído.
        strcpy(UltimaEntradaLectura.camino, camino);
        UltimaEntradaLectura.p_inodo = p_inodo;
#if DEBUG
        printf("\n[mi_read() -> Actualizamos la caché de lectura]\n");
#endif
    }
    else
    {
        // Utiliza el p_inodo de memoria.
        p_inodo = UltimaEntradaLectura.p_inodo;
#if DEBUG
        printf("\n[mi_read() -> Utilizamos la caché de lectura en vez de llamar"
               "a buscar_entrada()]\n");
#endif
    }
    // Realiza la lectura del archivo.
    bytes = mi_read_f(p_inodo, buf, offset, nbytes);
    if (bytes == -1)
    {
        return ERROR_PERMISO_LECTURA;
    }
    return bytes;
}

/* Función: mi_link:
* ------------------
* Esta función crea un link al contenido de un fichero en una nueva 
* localización.
* 
*  camino1: dirección del archivo a linkear.
*  camino2: dirección donde se crea el link al archivo.
*
* return: Exit_Success o código de error a procesar por 
*         mostrar_error_directorio.
*/
int mi_link(const char *camino1, const char *camino2)
{
    // Inicialización de las variables.
    unsigned int p_inodo_dir1 = 0;
    unsigned int p_inodo1 = 0;
    unsigned int p_entrada1 = 0;
    int error;

    // Busca el archivo a linkear en el disco.
    if ((error = buscar_entrada(camino1, &p_inodo_dir1, &p_inodo1,
                                &p_entrada1, 0, 0)) < 0)
    {
        return error;
    }
    // Lee el inodo relacionado con el archivo a linkear.
    struct inodo inodo1;
    if (leer_inodo(p_inodo1, &inodo1))
    {
        return ERROR_ACCESO_DISCO;
    }
    // Comprueba que el archivo tenga permisos de lectura.
    if ((inodo1.permisos & 4) != 4)
    {
        return ERROR_PERMISO_LECTURA;
    }
    // Inicialización de las variables.
    unsigned int p_inodo_dir2 = 0;
    unsigned int p_inodo2 = 0;
    unsigned int p_entrada2 = 0;

    // Espera para entrar en la sección crítica:
    mi_waitSem();

    // Crea la entrada del link en el directorio correspondiente.
    if ((error = buscar_entrada(camino2, &p_inodo_dir2, &p_inodo2,
                                &p_entrada2, 1, 6)) < 0)
    {
        mi_signalSem();
        return error;
    }
    mi_signalSem();

    // Lee la entrada del link en el directorio.
    struct entrada entrada2;
    if (mi_read_f(p_inodo_dir2, &entrada2,
                  sizeof(struct entrada) * (p_entrada2),
                  sizeof(struct entrada)) < 0)
    {
        return ERROR_ACCESO_DISCO;
    }
    // Actualiza el inodo enlazado al camino.
    entrada2.ninodo = p_inodo1;

    // Escribe la entrada del link en el directorio.
    if (mi_write_f(p_inodo_dir2, &entrada2,
                   sizeof(struct entrada) * (p_entrada2),
                   sizeof(struct entrada)) < 0)
    {
        return ERROR_ACCESO_DISCO;
    }

    // Espera para entrar en la sección crítica:
    mi_waitSem();

    // Libera el inodo creado con el buscar_entrada del link.
    if (liberar_inodo(p_inodo2) < 0)
    {
        mi_signalSem();
        return ERROR_ACCESO_DISCO;
    }
    mi_signalSem();

    // Espera para entrar en la sección crítica:
    mi_waitSem();

    // Actualiza los metadatos el inodo del archivo 1 y lo guarda.
    if (leer_inodo(p_inodo1, &inodo1))
    {
        mi_signalSem();
        return ERROR_ACCESO_DISCO;
    }
    inodo1.nlinks = inodo1.nlinks + 1;
    inodo1.ctime = time(NULL);
    if (escribir_inodo(p_inodo1, inodo1))
    {
        mi_signalSem();
        return ERROR_ACCESO_DISCO;
    }
    mi_signalSem();
    return EXIT_SUCCESS;
}

/* Función: mi_unlink:
* --------------------
* Borra la entrada de directorio especificada, esta función sirve tanto para
* borrar un enlace a un fichero como el contenido de este si no quedan enlaces.
*
*  camino: dirección del archivo a borrar.
*
* returns: Exit_Success o bien un código de error para ser tratado por 
*          mostrar_error_directorios.
*/
int mi_unlink(const char *camino)
{
    // Espera para entrar en la sección crítica:
    mi_waitSem();

    // Inicialización de las variables.
    unsigned int p_inodo_dir = 0;
    unsigned int p_inodo = 0;
    unsigned int p_entrada = 0;
    int error;

    // Busca el archivo a linkear en el disco.
    if ((error = buscar_entrada(camino, &p_inodo_dir, &p_inodo,
                                &p_entrada, 0, 0)) < 0)
    {
        mi_signalSem();
        return error;
    }
    // Lee el inodo del archivo a borrar.
    struct inodo inodo;
    if (leer_inodo(p_inodo, &inodo))
    {
        mi_signalSem();
        return ERROR_ACCESO_DISCO;
    }
    // Comprueba si es un directorio y está vacío.
    if (inodo.tipo == 'd' && inodo.tamEnBytesLog > 0)
    {
        mi_signalSem();
        return ERROR_DIRECTORIO_NO_VACIO;
    }
    // Lee el inodo del directorio.
    struct inodo inodo_dir;
    if (leer_inodo(p_inodo_dir, &inodo_dir))
    {
        mi_signalSem();
        return ERROR_ACCESO_DISCO;
    }
    // Obtiene el número de entradas que contiene el directorio.
    int num_entradas = inodo_dir.tamEnBytesLog / sizeof(struct entrada);

    // Comprueba si la entrada a eliminar es la última.
    if (p_entrada == num_entradas - 1)
    {

        // Elimina la última entrada.
        if (mi_truncar_f(p_inodo_dir, inodo_dir.tamEnBytesLog -
                                          sizeof(struct entrada)) < 0)
        {
            mi_signalSem();
            return ERROR_ACCESO_DISCO;
        }
    }
    else
    {
        // Lee la última entrada del directorio.
        struct entrada entrada;
        if (mi_read_f(p_inodo_dir, &entrada,
                      sizeof(struct entrada) * (num_entradas - 1),
                      sizeof(struct entrada)) < 0)
        {
            mi_signalSem();
            return ERROR_ACCESO_DISCO;
        }
        // Escribe la última entrada en la posición de la entrada a borrar.
        if (mi_write_f(p_inodo_dir, &entrada,
                       sizeof(struct entrada) * p_entrada,
                       sizeof(struct entrada)) < 0)
        {
            mi_signalSem();
            return ERROR_ACCESO_DISCO;
        }
        // Elimina la última entrada.
        if (mi_truncar_f(p_inodo_dir, inodo_dir.tamEnBytesLog -
                                          sizeof(struct entrada)) < 0)
        {
            mi_signalSem();
            return ERROR_ACCESO_DISCO;
        }
    }
    // Decrementa el número de enlaces al inodo.
    if (leer_inodo(p_inodo, &inodo))
    {
        mi_signalSem();
        return ERROR_ACCESO_DISCO;
    }
    inodo.nlinks = inodo.nlinks - 1;

    // Si no quedan enlaces al inodo entonces se elimina.
    if (!inodo.nlinks)
    {
        if (liberar_inodo(p_inodo) < 0)
        {
            mi_signalSem();
            return ERROR_ACCESO_DISCO;
        }
    }
    else
    {
        // Actualiza el ctime y guarda el inodo.
        inodo.ctime = time(NULL);
        if (escribir_inodo(p_inodo, inodo))
        {
            mi_signalSem();
            return ERROR_ACCESO_DISCO;
        }
    }
    mi_signalSem();
    return EXIT_SUCCESS;
}

/* Función: mi_unlink_r:
* ----------------------
* Esta función borra de forma recursiva todos los elementos dentro de la 
* estructura de directorios.
*
*  camino: ruta del directorio donde comienza la eliminación de elementos.
*
* returns: Exit_Success o bien un código de error a ser tratado por 
*          mostrar_error_directorios. 
*/
int mi_unlink_r(const char *camino)
{
    // Inicialización de las variables.
    unsigned int p_inodo_dir = 0;
    unsigned int p_inodo = 0;
    unsigned int p_entrada = 0;
    int error;

    // Busca el p_inodo del directorio.
    if ((error = buscar_entrada(camino, &p_inodo_dir, &p_inodo,
                                &p_entrada, 0, 0)) < 0)
    {
        printf("%s\n", camino);
        return error;
    }
    // Variables para la lectura del contenido del inodo.
    struct entrada entrada[BLOCKSIZE / sizeof(struct entrada)];
    int offset = 0;
    int leidos;

    // Lee el contenido del inodo.
    if ((leidos = mi_read_f(p_inodo, &entrada, offset, BLOCKSIZE)) < 0)
    {
        return ERROR_ACCESO_DISCO;
    }
    // Recorre todas las entradas del directorio.
    while (leidos > 0)
    {
        // Actualiza el offset de lectura e índice.
        int offset = offset + leidos;
        int entradas = 0;

        // Recorre todas las entradas leídas.
        while (entradas < (leidos / sizeof(struct entrada)))
        {
            // Lee el inodo de la entrada.
            struct inodo inodo;
            if (leer_inodo(entrada[entradas].ninodo, &inodo))
            {
                return ERROR_ACCESO_DISCO;
            }
            // Comprueba si es un directorio.
            if (inodo.tipo == 'd')
            {
                // Genera el camino para la recursividad.
                char subcamino[60];
                memset(subcamino, 0, sizeof(char) * 60);
                strcat(subcamino, camino);
                strcat(subcamino, entrada[entradas].nombre);
                strcat(subcamino, "/");

                // Si es un directorio, entonces llama a la función otra vez.
                if ((error = mi_unlink_r(subcamino)) < 0)
                {
                    return error;
                }
            }
            else
            {
                // Genera el camino para el borrado del archivo.
                char subcamino[60];
                memset(subcamino, 0, sizeof(char) * 60);
                strcat(subcamino, camino);
                strcat(subcamino, entrada[entradas].nombre);

                // Si es un fichero, borra este del sistema.
                if ((error = mi_unlink(subcamino)) < 0)
                {
                    return error;
                }
            }
            // Procesa siguiente entrada.
            entradas++;
        }
        // Lee siguiente conjunto de entradas.
        if ((leidos = mi_read_f(p_inodo, &entrada, offset, BLOCKSIZE)) < 0)
        {
            return ERROR_ACCESO_DISCO;
        }
    }
    // Elimina el directorio indicado por parámetro.
    if ((error = mi_unlink(camino)) < 0)
    {
        return error;
    }
    return EXIT_SUCCESS;
}

/* Función: mostrar_error_directorios:
* ------------------------------------
* Esta función trata los error producidos por las funciones de la librería 
* directorios, mostrando la excepción por pantalla.
*
*  error: código de error.
*/
void mostrar_error_directorios(int error)
{
    switch (error)
    {
    case -1:
        fprintf(stderr, "Error: Camino incorrecto.\n");
        break;
    case -2:
        fprintf(stderr, "Error: Permiso denegado de lectura.\n");
        break;
    case -3:
        fprintf(stderr, "Error: No existe el archivo o el directorio.\n");
        break;
    case -4:
        fprintf(stderr, "Error: No existe algún directorio intermedio.\n");
        break;
    case -5:
        fprintf(stderr, "Error: Permiso denegado de escritura.\n");
        break;
    case -6:
        fprintf(stderr, "Error: El archivo ya existe.\n");
        break;
    case -7:
        fprintf(stderr, "Error: No es un directorio.\n");
        break;
    case -8:
        fprintf(stderr, "Error: No se ha podico acceder a disco.\n");
        break;
    case -9:
        fprintf(stderr, "Error: El directorio no esta vacío.\n");
    }
}
